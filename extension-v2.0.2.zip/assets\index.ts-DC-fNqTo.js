import{u as Pe,a as Re,b as $e,V as ze,c as He,v as Ne,t as _e,j as re,d as ae,e as we,R as ke}from"./index-Cdy1wpRV.js";import{s as F,M,D as Ae}from"./protocol-D3q8XD41.js";const Fe="https://github.com/remarkjs/react-markdown/blob/main/changelog.md",pe=[],ue={allowDangerousHtml:!0},Be=/^(https?|ircs?|mailto|xmpp)$/i,Oe=[{from:"astPlugins",id:"remove-buggy-html-in-markdown-parser"},{from:"allowDangerousHtml",id:"remove-buggy-html-in-markdown-parser"},{from:"allowNode",id:"replace-allownode-allowedtypes-and-disallowedtypes",to:"allowElement"},{from:"allowedTypes",id:"replace-allownode-allowedtypes-and-disallowedtypes",to:"allowedElements"},{from:"className",id:"remove-classname"},{from:"disallowedTypes",id:"replace-allownode-allowedtypes-and-disallowedtypes",to:"disallowedElements"},{from:"escapeHtml",id:"remove-buggy-html-in-markdown-parser"},{from:"includeElementIndex",id:"#remove-includeelementindex"},{from:"includeNodeIndex",id:"change-includenodeindex-to-includeelementindex"},{from:"linkTarget",id:"remove-linktarget"},{from:"plugins",id:"change-plugins-to-remarkplugins",to:"remarkPlugins"},{from:"rawSourcePos",id:"#remove-rawsourcepos"},{from:"renderers",id:"change-renderers-to-components",to:"components"},{from:"source",id:"change-source-to-children",to:"children"},{from:"sourcePos",id:"#remove-sourcepos"},{from:"transformImageUri",id:"#add-urltransform",to:"urlTransform"},{from:"transformLinkUri",id:"#add-urltransform",to:"urlTransform"}];function ve(e){const t=De(e),o=qe(e);return je(t.runSync(t.parse(o),o),e)}function De(e){const t=e.rehypePlugins||pe,o=e.remarkPlugins||pe,n=e.remarkRehypeOptions?{...e.remarkRehypeOptions,...ue}:ue;return Pe().use(Re).use(o).use($e,n).use(t)}function qe(e){const t=e.children||"",o=new ze;return typeof t=="string"&&(o.value=t),o}function je(e,t){const o=t.allowedElements,n=t.allowElement,r=t.components,l=t.disallowedElements,p=t.skipHtml,a=t.unwrapDisallowed,s=t.urlTransform||Ke;for(const i of Oe)Object.hasOwn(t,i.from)&&He("Unexpected `"+i.from+"` prop, "+(i.to?"use `"+i.to+"` instead":"remove it")+" (see <"+Fe+"#"+i.id+"> for more info)");return Ne(e,m),_e(e,{Fragment:re.Fragment,components:r,ignoreInvalidStyle:!0,jsx:re.jsx,jsxs:re.jsxs,passKeys:!0,passNode:!0});function m(i,c,d){if(i.type==="raw"&&d&&typeof c=="number")return p?d.children.splice(c,1):d.children[c]={type:"text",value:i.value},c;if(i.type==="element"){let f;for(f in ae)if(Object.hasOwn(ae,f)&&Object.hasOwn(i.properties,f)){const h=i.properties[f],g=ae[f];(g===null||g.includes(i.tagName))&&(i.properties[f]=s(String(h||""),f,i))}}if(i.type==="element"){let f=o?!o.includes(i.tagName):l?l.includes(i.tagName):!1;if(!f&&n&&typeof c=="number"&&(f=!n(i,c,d)),f&&d&&typeof c=="number")return a&&i.children?d.children.splice(c,1,...i.children):d.children.splice(c,1),c}}}function Ke(e){const t=e.indexOf(":"),o=e.indexOf("?"),n=e.indexOf("#"),r=e.indexOf("/");return t===-1||r!==-1&&t>r||o!==-1&&t>o||n!==-1&&t>n||Be.test(e.slice(0,t))?e:""}function Y(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const fe=["script","style","noscript","svg","iframe","canvas","nav","header","footer","aside","form","button","input","select","textarea","[role='navigation']","[role='banner']","[role='contentinfo']","[role='search']","[role='complementary']","[aria-hidden='true']",".mw-jump-link",".mw-jump-links","#mw-navigation","#mw-panel","#mw-head","#mw-page-base","#mw-head-base","#siteNotice","#contentSub","#jump-to-nav","#vector-toc","#vector-main-menu","#vector-page-tools","#vector-sticky-header","#p-lang-btn","#p-personal","#p-views","#p-namespaces","#p-cactions","#p-search",".vector-header",".vector-header-container",".vector-sticky-header",".vector-toc",".vector-toc-landmark",".vector-page-toolbar",".vector-page-toolbar-container",".vector-menu",".vector-dropdown",".vector-column-start",".vector-column-end",".mw-portlet",".mw-indicators",".mw-editsection",".mw-cite-backlink",".noprint",".navbox",".vertical-navbox",".sidebar",".sistersitebox","#toc",".toc",".mw-table-of-contents",".toccolours",".site-nav",".site-header",".site-footer","#aka-root","#aka-keyword-tile-root","#aka-keyword-popup-root","#hs-ai-modal-root","#hs-keyword-tile-root","#hs-keyword-popup-root"].join(","),U=new Set("search user menu article talk language watch edit contents jump wikipedia wikimedia commons portal help login log sign create account donate tools appearance hide show more less read view history main page random page about disclaimers contact download print share cite references notes external links see also navigation sidebar toolbar footer header cookie cookies privacy subscribe newsletter follow toggle subsection".split(/\s+/)),Ue=/jump to content|jump to navigation|jump to search|main menu|create account|log[\s-]?in|contents\s*hide|toggle\s+\w+\s+subsection|user menu|donate\b|from wikipedia,? the free encyclopedia|languages?\s*$|add languages|appearance\b|vector-toc|edit links|view history|\(\s*top\s*\)/i;function Ve(){return document.querySelector("#mw-content-text .mw-parser-output")||document.querySelector("#mw-content-text")||document.querySelector("#bodyContent")||document.querySelector("#content")||document.querySelector("article")||document.querySelector("[role='main']")||document.querySelector("main")||document.body}function We(e){return e.replace(/[ \t\f\v]+/g," ").replace(/\n{3,}/g,`

`).trim()}function P(e){const t=e.trim();if(!t||Ue.test(t))return!0;const o=t.toLowerCase();if(/^(search|user menu|article|talk|language|watch|edit|contents|donate|log in|create account)\b/.test(o)||/\btoggle\b/i.test(t)&&/\bsubsection\b/i.test(t))return!0;const n=o.match(/[a-z][a-z0-9-]{2,}/g)||[];if(n.length===0)return!0;let r=0;for(const l of n)U.has(l)&&r++;return r>=3&&n.length<=40||r>=5||n.length>=8&&r/n.length>=.45}function J(e){const t=e.split(/\r?\n/),o=[];for(const r of t){const l=r.trim();l&&(P(l)||l.length<3||o.push(l))}let n=o.join(`
`);return n=n.replace(/Jump to (content|search|navigation)[.\s]*/gi,"").replace(/\bFrom Wikipedia,? the free encyclopedia\b/gi,"").replace(/\bContents\s*hide\b/gi,"").replace(/\bToggle \w+ subsection\b/gi,"").replace(/\bCreate account\b/gi,"").replace(/\bLog in\b/gi,"").replace(/\bMain menu\b/gi,"").replace(/\bDonate\b/gi,""),We(n)}function Q(e=4e4){var r;const t=Ve();if(!t)return"";let o="";try{const l=t.cloneNode(!0);try{l.querySelectorAll(fe).forEach(p=>p.remove())}catch{}o=l.innerText||l.textContent||""}catch{o=((r=document.body)==null?void 0:r.innerText)||""}let n=J(o);if(n.length<40){const l=document.querySelector("#mw-content-text .mw-parser-output");if(l&&l!==t)try{const p=l.cloneNode(!0);p.querySelectorAll(fe).forEach(a=>a.remove()),n=J(p.innerText||p.textContent||"")}catch{}}return n.length>e&&(n=`${n.slice(0,e)}…`),n}function Ee(e,t,o=220){const n=t??Q(12e3);if(!n||!e.trim())return"";const r=new RegExp(`\\b${e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\b`,"i"),p=n.split(new RegExp("(?<=[.!?])\\s+|\\n+")).map(a=>a.trim()).filter(a=>a.length>=24&&a.length<=420).filter(a=>r.test(a)).filter(a=>!P(a))[0];return p?p.slice(0,o):""}function Se(e,t=2500){const o=Q(12e3);if(!o)return"";const n=e.trim();if(!n)return o.slice(0,t);const r=Ee(n,o,400);if(r){const c=o.toLowerCase().indexOf(r.toLowerCase().slice(0,40));if(c>=0){const d=Math.floor((t-r.length)/2),f=Math.max(0,c-Math.max(d,200)),h=Math.min(o.length,f+t);let g=o.slice(f,h);return P(g)?r:(f>0&&(g=`…${g}`),h<o.length&&(g=`${g}…`),J(g)||r)}return r}const p=o.toLowerCase().indexOf(n.toLowerCase());if(p<0){const c=o.slice(0,t);return P(c)?"":c}const a=Math.floor((t-n.length)/2),s=Math.max(0,p-a),m=Math.min(o.length,p+n.length+a);let i=o.slice(s,m);return i=J(i),!i||P(i)?"":(s>0&&(i=`…${i}`),m<o.length&&(i=`${i}…`),i)}function Ge(e,t=48){const o=e.trim().replace(/\s+/g," ");return o.length<=t?o:`${o.slice(0,Math.max(1,t-1))}…`}function Ce(e,t){const o=(document.title||"this page").trim();return`Key term “${e}” on “${o}”. Open again for a full Meaning / On this page / Why it matters summary.`}const D=[{bg:"#fff59d",border:"#f0e68c",text:"#3d3420"},{bg:"#f8bbd0",border:"#f0a8c0",text:"#4a2030"},{bg:"#bbdefb",border:"#a8d0f0",text:"#1e3048"},{bg:"#c8e6c9",border:"#b5d8b8",text:"#1e3a28"},{bg:"#ffe0b2",border:"#f0d0a0",text:"#4a3020"},{bg:"#e1bee7",border:"#d0aee0",text:"#3a2048"},{bg:"#b2dfdb",border:"#a0d0cc",text:"#1e3a38"},{bg:"#ffccbc",border:"#f0b8a8",text:"#4a2820"}],ie="hs_tile_position",me=new Set("a an the and or but if in on at to for of as is was are were be been being this that these those it its with from by into over after before about between not no yes you your we they he she his her their our my me him them us will would can could should may might must shall do does did done having have has had what when where which who how why all any each few more most other some such than too very just also only then there here using use used via per etc http https www com".split(/\s+/)),q="aka-keyword-tile-root",W="aka-keyword-popup-root",_="aka-kw-mark",ge=120,j=new Map;let C=null,E=null,G=null,B=null,Te=null,ee={onSaveHighlight:async()=>{},onFeaturePatch:async()=>{},isContextValid:()=>{var e;try{return!!((e=chrome.runtime)!=null&&e.id)}catch{return!1}}};function Xe(e){ee=e}function le(){return ee.isContextValid()}function Le(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Ye(e,t=8){const o=new Map,n=String(e||"").match(/[A-Za-z][A-Za-z0-9+.#-]{2,}/g)||[];for(const a of n){const s=a.toLowerCase();me.has(s)||U.has(s)||s.length<4||s.length>40||o.set(s,(o.get(s)??0)+1)}for(const a of String(document.title||"").toLowerCase().split(/[^a-z0-9+.#-]+/).filter(Boolean))a.length>=4&&!me.has(a)&&!U.has(a)&&o.set(a,(o.get(a)??0)+3);const r=[...o.entries()].sort((a,s)=>s[1]-a[1]||s[0].length-a[0].length).slice(0,t*3),l=[],p=new Set;for(let a=0;a<r.length;a++){const s=r[a][0];if(l.length>=t)break;if(p.has(s)||U.has(s))continue;const m=new RegExp(`\\b(${Le(s)})\\b`,"i"),i=String(e||"").match(m),c=(i==null?void 0:i[1])??s;if(U.has(c.toLowerCase()))continue;p.add(s);const d=Ee(c,e,180),f=d&&!P(d)?d:Ce(c);l.push({term:c,summary:f,colorIndex:a%D.length})}return l}function te(){document.querySelectorAll(`mark.${_}`).forEach(e=>{const t=e.parentNode;t&&(t.replaceChild(document.createTextNode(e.textContent||""),e),t.normalize())})}function he(e){var o,n;if(!e||e.nodeType!==1)return!0;const t=e.tagName;return!!(/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|SELECT|OPTION|SVG|CANVAS|IFRAME|CODE|PRE|KBD|SAMP)$/i.test(t)||e.isContentEditable||(o=e.closest)!=null&&o.call(e,"[contenteditable], [role='textbox'], [role='searchbox'], [role='combobox'], [aria-multiline='true']")||e.id===q||e.id===W||e.id==="aka-root"||(n=e.closest)!=null&&n.call(e,`#${q}, #${W}, #aka-root, mark.${_}`))}function Je(e){var a;if(te(),j.size===0)return 0;const t=[...j.values()].map(s=>s.term).filter(Boolean).sort((s,m)=>m.length-s.length);if(!t.length)return 0;const o=new RegExp(`(${t.map(s=>{const m=Le(s);return!/\s/.test(s)&&s.length<=12?`\\b${m}\\b`:m}).join("|")})`,"gi"),n=document.querySelector("article")||document.querySelector("main")||document.body;if(!n||he(n))return 0;const r=document.createTreeWalker(n,NodeFilter.SHOW_TEXT,{acceptNode(s){var i;if(!((i=s.nodeValue)!=null&&i.trim()))return NodeFilter.FILTER_REJECT;const m=s.parentElement;return!m||he(m)||m.closest(`mark.${_}`)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),l=[];for(;r.nextNode();)l.push(r.currentNode);let p=0;for(const s of l){if(p>=ge)break;const m=s.nodeValue??"";if(o.lastIndex=0,!o.test(m)){o.lastIndex=0;continue}o.lastIndex=0;const i=document.createDocumentFragment();let c=0,d,f=!1;for(;(d=o.exec(m))!==null&&!(p>=ge);){const h=d[0],g=h.toLowerCase(),v=j.get(g);if(d.index>c&&i.appendChild(document.createTextNode(m.slice(c,d.index))),!v){i.appendChild(document.createTextNode(h)),c=d.index+h.length;continue}const x=D[v.colorIndex%D.length],u=document.createElement("mark");u.className=_,u.dataset.akaKey=g,u.textContent=h,u.style.cssText=`
        background: ${x.bg};
        color: inherit;
        border: 1px solid ${x.border};
        border-radius: 2px;
        padding: 0 3px;
        margin: 0 1px;
        cursor: pointer;
        box-shadow: none;
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
      `,u.title="Click for context · Esc to close",u.addEventListener("click",w=>{w.preventDefault(),w.stopPropagation(),se(v,u)}),i.appendChild(u),f=!0,p++,c=d.index+h.length}!f&&c===0||(c<m.length&&i.appendChild(document.createTextNode(m.slice(c))),(a=s.parentNode)==null||a.replaceChild(i,s))}return p}function O(){var e;G&&(G(),G=null),E==null||E.remove(),E=null,(e=document.getElementById(W))==null||e.remove()}function Ze(e,t){return`${e}

${t}`.trim()}function Qe(e,t){var v;if(!e.isConnected)return;const o=10,n=12,r=Math.min(360,Math.max(240,document.documentElement.clientWidth-24)),l=(v=e.shadowRoot)==null?void 0:v.querySelector(".card"),p=(l==null?void 0:l.offsetHeight)||220,a=window.scrollX||0,s=window.scrollY||0;let m;if(t&&document.contains(t))m=t.getBoundingClientRect();else{const x=document.getElementById(q);m=(x==null?void 0:x.getBoundingClientRect())||{top:80,bottom:110,left:window.innerWidth-380,width:0,height:0}}const i=window.innerHeight-m.bottom;let c;i>=Math.min(p+o,140)?c=m.bottom+o:c=m.top-p-o;let d=m.left+(m.width||0)/2-r/2;const f=Math.max(document.documentElement.scrollWidth,document.documentElement.clientWidth);let h=d+a;h=Math.max(n,Math.min(h,f-r-n));const g=Math.max(n,c+s);e.style.top=`${g}px`,e.style.left=`${h}px`,e.style.width=`${r}px`}function se(e,t){var H;O(),E=document.createElement("div"),E.id=W,E.style.cssText="position:absolute;z-index:2147483647;opacity:0;transform:translateY(6px) scale(0.97);";const o=E.attachShadow({mode:"open"}),n=D[e.colorIndex%D.length],r=e.summary&&!P(e.summary)?e.summary:Ce(e.term);let l=r;const p=()=>Ze(e.term,l),a=e.term.toLowerCase();let s=t&&document.contains(t)?t:null;!s&&a&&(s=document.querySelector(`mark.${_}[data-aka-key="${CSS.escape(a)}"]`));const m=crypto.randomUUID();o.innerHTML=`
    <style>
      .card {
        font-family: "Segoe UI", system-ui, sans-serif;
        width: 100%; background: #fffef8; border: 1px solid #e8e4d8;
        border-radius: 10px; box-shadow: 0 4px 16px rgba(60,50,30,0.12);
        overflow: hidden; color: #3d3420;
      }
      .accent { height: 6px; background: ${n.bg}; border-bottom: 1px solid ${n.border}; }
      .head {
        display: flex; align-items: flex-start; justify-content: space-between;
        gap: 10px; padding: 12px 14px 8px;
      }
      .head-actions { display: flex; align-items: center; gap: 7px; }
      .term {
        font-size: 16px; font-weight: 780; letter-spacing: -0.02em; color: #2c2416;
        line-height: 1.25; word-break: break-word;
      }
      .badge {
        display: inline-block; margin-top: 6px; font-size: 10px; font-weight: 650;
        letter-spacing: 0.03em; text-transform: uppercase; padding: 3px 8px;
        border-radius: 4px; background: ${n.bg}; border: 1px solid ${n.border};
        color: ${n.text};
      }
      .status {
        margin: 0 14px 6px; font-size: 11px; color: #8a8272;
      }
      .close {
        border: 1px solid #e0dccf; background: #f7f5ee; color: #5c5548;
        width: 28px; height: 28px; border-radius: 6px; cursor: pointer; font-size: 16px;
      }
      .close:hover { background: #efece3; color: #9a3412; }
      .copy-top {
        border: 1px solid #e0dccf; background: #fff; color: #5c5548;
        border-radius: 6px; width: 28px; height: 28px; padding: 0; cursor: pointer;
        display: inline-grid; place-items: center;
      }
      .copy-top:hover { background: #f3f0e6; }
      .copy-top svg { width: 14px; height: 14px; stroke: currentColor; fill: none; stroke-width: 1.8; }
      .body {
        padding: 2px 14px 10px; max-height: min(360px, 58vh); overflow: auto;
        font-size: 13px; line-height: 1.55; color: #4a4336; word-break: break-word;
      }
      .body p { margin: 0 0 8px; }
      .body p:last-child { margin-bottom: 0; }
      .body h1, .body h2, .body h3 { margin: 10px 0 5px; font-size: 14px; line-height: 1.3; }
      .body ul, .body ol { margin: 5px 0 9px; padding-left: 20px; }
      .body li { margin: 3px 0; }
      .body code { padding: 1px 4px; border-radius: 3px; background: #f1eee4; font-family: ui-monospace, Menlo, Consolas, monospace; }
      .actions {
        display: flex; align-items: center; gap: 8px;
        padding: 10px 14px 12px; border-top: 1px solid #ebe6da; background: #faf8f1;
      }
      .abtn {
        display: inline-flex; align-items: center; gap: 5px;
        border: 1px solid #e0dccf; background: #fff; color: #3d3420;
        border-radius: 6px; padding: 7px 11px; font-size: 12px; font-weight: 650; cursor: pointer;
      }
      .abtn:hover { background: #f3f0e6; }
      .abtn-save { background: #fff59d; border-color: #f0e68c; }
      .abtn-save:hover { background: #fff176; }
      .abtn-save:disabled {
        background: #e8f5e9; border-color: #c8e6c9; color: #2e7d32; cursor: default;
      }
      .hint { margin-left: auto; font-size: 10.5px; color: #8a8272; }
      .kbd {
        font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 10px;
        padding: 2px 6px; border-radius: 4px; border: 1px solid #e0dccf; background: #fff;
      }
    </style>
    <div class="card">
      <div class="accent"></div>
      <div class="head">
        <div>
          <div class="term" id="term">${Y(e.term)}</div>
          <span class="badge">Keyword summary</span>
        </div>
        <div class="head-actions">
          <button class="copy-top" type="button" id="copy" aria-label="Copy response" title="Copy">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M15 9V5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h4"></path></svg>
          </button>
          <button class="close" type="button" aria-label="Close" title="Close (Esc)" id="close">&times;</button>
        </div>
      </div>
      <div class="status" id="status">Generating insight…</div>
      <div class="body" id="body">Explaining “${Y(e.term)}”…</div>
      <div class="actions">
        <button class="abtn abtn-save" type="button" id="save">Save</button>
        <span class="hint"><span class="kbd">Esc</span> close</span>
      </div>
    </div>
  `;const i=o.getElementById("body"),c=we(i),d=o.getElementById("status"),f=k=>{c.render(ke.createElement(ve,null,k))};f(`Explaining “${e.term}”…`),(H=o.getElementById("close"))==null||H.addEventListener("click",O);const h=o.getElementById("save"),g=o.getElementById("copy");g==null||g.addEventListener("click",()=>{var b;const k=()=>{if(!g)return;const S=g.innerHTML;g.textContent="Copied!",setTimeout(()=>{g.innerHTML=S},1400)},L=p(),R=()=>{const S=document.createElement("textarea");S.value=L,document.body.appendChild(S),S.select();try{document.execCommand("copy"),k()}catch{}S.remove()};(b=navigator.clipboard)!=null&&b.writeText?navigator.clipboard.writeText(L).then(k).catch(R):R()}),h==null||h.addEventListener("click",()=>{if(!le()){window.location.reload();return}(async()=>{try{await ee.onSaveHighlight(p()),h&&(h.disabled=!0,h.textContent="Saved!")}catch{h&&(h.textContent="Failed")}})()}),document.documentElement.appendChild(E);const v=()=>{(!s||!document.contains(s))&&a&&(s=document.querySelector(`mark.${_}[data-aka-key="${CSS.escape(a)}"]`)),E&&Qe(E,s)};v(),requestAnimationFrame(()=>{E&&(E.style.transition="opacity 0.2s ease, transform 0.2s ease",E.style.opacity="1",E.style.transform="translateY(0) scale(1)",v())});const x=()=>v();window.addEventListener("resize",x);const u=k=>{const L=k.composedPath();!L.includes(E)&&!L.some(R=>{var b;return R instanceof Element&&((b=R.classList)==null?void 0:b.contains(_))})&&!L.some(R=>R instanceof Element&&R.id===q)&&O()};setTimeout(()=>document.addEventListener("mousedown",u,!0),0);let w="";const y=k=>{l=r,f(r),d.textContent=k},T=k=>{var L;if(k.requestId===m){if(k.type===M.AI_STREAM_CHUNK&&k.chunk){if(w+=k.chunk,P(w)&&w.length>80){y("Filtered page chrome — retry");return}l=w,f(w),d.textContent="Streaming…",v()}k.type===M.AI_STREAM_DONE&&(chrome.runtime.onMessage.removeListener(T),k.error?y(k.error):!w.trim()||P(w)?y("Done"):(l=w,f(w),d.textContent=(L=k.envelope)!=null&&L.latencyMs?`${k.envelope.latencyMs}ms`:"Done"),v())}};chrome.runtime.onMessage.addListener(T);let A=Se(e.term,2500);A&&P(A)&&(A=""),F({type:M.AI_STREAM,requestId:m,action:"explain",text:e.term,selectedText:e.term,pageContext:A||void 0,pageTitle:document.title,url:location.href}).catch(k=>{y(k instanceof Error?k.message:"AI failed"),chrome.runtime.onMessage.removeListener(T)}),G=()=>{window.removeEventListener("resize",x),document.removeEventListener("mousedown",u,!0),chrome.runtime.onMessage.removeListener(T)}}function et(e,t,o,n){const l=Math.max(8,window.innerWidth-o-8),p=Math.max(8,window.innerHeight-n-8);return{left:Math.min(Math.max(8,e),l),top:Math.min(Math.max(8,t),p)}}function V(e,t,o){const n=e.offsetWidth||210,r=e.offsetHeight||56,l=et(t,o,n,r);return e.style.left=`${l.left}px`,e.style.top=`${l.top}px`,e.style.right="auto",e.style.bottom="auto",l}function tt(e,t){if(le())try{chrome.storage.local.set({[ie]:{left:e,top:t}},()=>{var o;try{(o=chrome.runtime)==null||o.lastError}catch{}})}catch{}}function ot(e){if(!le()){e(null);return}try{chrome.storage.local.get([ie],t=>{var o;try{if((o=chrome.runtime)!=null&&o.lastError){e(null);return}const n=t==null?void 0:t[ie];n&&typeof n.left=="number"&&typeof n.top=="number"?e({left:n.left,top:n.top}):e(null)}catch{e(null)}})}catch{e(null)}}function nt(e,t){let o=!1,n=!1,r=0,l=0,p=0,a=0;const s=5,m=c=>{var h,g;if(!o)return;const d=c.clientX-r,f=c.clientY-l;!n&&(Math.abs(d)>s||Math.abs(f)>s)&&(n=!0,e.classList.add("aka-dragging"),(g=(h=e.shadowRoot)==null?void 0:h.querySelector(".tile"))==null||g.classList.add("dragging"),t.style.cursor="grabbing"),n&&(c.preventDefault(),V(e,p+d,a+f))},i=c=>{var d,f,h;if(o){o=!1,e.classList.remove("aka-dragging"),(f=(d=e.shadowRoot)==null?void 0:d.querySelector(".tile"))==null||f.classList.remove("dragging"),t.style.cursor="grab",window.removeEventListener("pointermove",m,!0),window.removeEventListener("pointerup",i,!0),window.removeEventListener("pointercancel",i,!0);try{(h=t.releasePointerCapture)==null||h.call(t,c.pointerId)}catch{}if(n){const g=parseFloat(e.style.left)||0,v=parseFloat(e.style.top)||0,x=V(e,g,v);tt(x.left,x.top),e._akaSkipNextHeaderClick=!0,setTimeout(()=>{e._akaSkipNextHeaderClick=!1},0)}}};t.addEventListener("pointerdown",c=>{var h,g;if(c.button!==0)return;const d=c.target;if((h=d==null?void 0:d.closest)!=null&&h.call(d,".gear-btn, .clear-btn, .prefs-panel, button, input, label, .chip, #list"))return;o=!0,n=!1,r=c.clientX,l=c.clientY;const f=e.getBoundingClientRect();p=f.left,a=f.top,V(e,p,a),(g=t.setPointerCapture)==null||g.call(t,c.pointerId),window.addEventListener("pointermove",m,!0),window.addEventListener("pointerup",i,!0),window.addEventListener("pointercancel",i,!0)}),B&&window.removeEventListener("resize",B),B=()=>{const c=parseFloat(e.style.left),d=parseFloat(e.style.top);Number.isFinite(c)&&Number.isFinite(d)&&V(e,c,d)},window.addEventListener("resize",B)}function de(){var e;B&&(window.removeEventListener("resize",B),B=null),C==null||C.remove(),C=null,(e=document.getElementById(q))==null||e.remove()}function rt(e,t){if(de(),!e.length)return;let o=!1,n=!1;C=document.createElement("div"),C.id=q,C.style.cssText="all:initial;position:fixed;top:16px;right:16px;z-index:2147483645;";const r=C.attachShadow({mode:"open"}),l=document.documentElement.dataset.akaTheme==="dark"?"dark":"light";r.innerHTML=`
    <style>
      :host { all: initial; }
      .tile {
        font-family: "Segoe UI", system-ui, sans-serif;
        display: flex; flex-direction: column; width: 210px;
        border-radius: 10px; background: #fffef8; border: 1px solid #e8e4d8;
        box-shadow: 0 2px 8px rgba(60,50,30,0.08); color: #3d3420;
        user-select: none; overflow: hidden; touch-action: none;
      }
      :host(.aka-dragging) .tile, .tile.dragging {
        box-shadow: 0 6px 18px rgba(60,50,30,0.16); opacity: 0.96;
      }
      .header {
        display: flex; align-items: flex-start; gap: 8px;
        padding: 11px 12px; cursor: grab;
      }
      .header:hover { background: #faf7ef; }
      .header:active { cursor: grabbing; }
      .drag-hint {
        font-size: 9px; color: #a89f8c; letter-spacing: 0.08em; margin-bottom: 2px;
      }
      .meta { flex: 1; min-width: 0; }
      .title-row { display: flex; align-items: center; gap: 6px; }
      .title { font-size: 12px; font-weight: 650; color: #2c2416; }
      .chevron { font-size: 10px; color: #8a8272; margin-left: auto; transition: transform 0.18s; }
      .tile.open .chevron { transform: rotate(180deg); }
      .status { font-size: 11px; color: #6b6354; margin-top: 3px; line-height: 1.35; }
      .header-actions {
        display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0;
      }
      .gear-btn, .clear-btn {
        border: 1px solid #e0dccf; background: #f7f5ee; color: #5c5548;
        border-radius: 6px; cursor: pointer; outline: none; touch-action: auto;
      }
      .gear-btn { width: 26px; height: 26px; padding: 0; font-size: 13px; }
      .gear-btn.active { background: #ebe6da; border-color: #cfc8b6; }
      .clear-btn { padding: 3px 8px; font-size: 10.5px; font-weight: 600; }
      .clear-btn:disabled { opacity: 0.4; cursor: default; }
      .prefs-panel {
        display: none; flex-direction: column; gap: 8px;
        padding: 8px 10px 10px; border-top: 1px solid #ebe6da; touch-action: auto;
      }
      .tile.prefs-open .prefs-panel { display: flex; }
      .tile.prefs-open .word-panel { display: none !important; }
      .prefs-heading {
        font-size: 10px; font-weight: 700; letter-spacing: 0.06em;
        text-transform: uppercase; color: #8a8272; margin: 2px 0 0;
      }
      .pref-row {
        display: flex; align-items: center; justify-content: space-between;
        gap: 10px; font-size: 11.5px; font-weight: 550; color: #3d3420;
      }
      .switch { position: relative; width: 34px; height: 18px; flex-shrink: 0; }
      .switch input { opacity: 0; width: 0; height: 0; position: absolute; }
      .switch-slider {
        position: absolute; inset: 0; background: #d5cfbf; border-radius: 999px; cursor: pointer;
      }
      .switch-slider::before {
        content: ''; position: absolute; width: 14px; height: 14px; left: 2px; top: 2px;
        background: #fff; border-radius: 50%; transition: transform 0.15s;
        box-shadow: 0 1px 2px rgba(0,0,0,0.15);
      }
      .switch input:checked + .switch-slider { background: #5b8f3a; }
      .switch input:checked + .switch-slider::before { transform: translateX(16px); }
      .word-panel {
        display: none; flex-direction: column; gap: 6px;
        padding: 0 10px 10px; max-height: min(340px, 55vh); overflow: auto;
        border-top: 1px solid #ebe6da; padding-top: 8px; touch-action: auto;
      }
      .tile.open .word-panel { display: flex; }
      .hint { font-size: 10px; color: #8a8272; padding: 0 2px 2px; }
      .chip {
        display: block; width: 100%; text-align: left; font-size: 12px; font-weight: 600;
        padding: 7px 9px; border-radius: 6px; border: 1px solid transparent;
        cursor: pointer; outline: none; touch-action: auto;
      }
      .chip:hover { opacity: 0.9; }
      .tile[data-theme="dark"] {
        background: rgba(18,28,48,0.92); border-color: rgba(160,190,230,0.16);
        box-shadow: 0 8px 24px rgba(0,0,0,0.4); color: #e6eef8;
      }
      .tile[data-theme="dark"] .title { color: #e6eef8; }
      .tile[data-theme="dark"] .status, .tile[data-theme="dark"] .hint { color: #9db0c8; }
      .tile[data-theme="dark"] .drag-hint, .tile[data-theme="dark"] .prefs-heading { color: #7a8fa8; }
      .tile[data-theme="dark"] .gear-btn, .tile[data-theme="dark"] .clear-btn {
        border-color: rgba(160,190,230,0.18); background: rgba(30,42,68,0.9); color: #c5d4ef;
      }
      .tile[data-theme="dark"] .pref-row { color: #e6eef8; }
      .tile[data-theme="dark"] .header:hover { background: rgba(30,42,68,0.55); }
      .tile[data-theme="dark"] .switch-slider { background: #3a4a62; }
      .tile[data-theme="dark"] .switch input:checked + .switch-slider { background: #4ade80; }
    </style>
    <div class="tile" data-theme="${l}" id="tile">
      <div class="header" id="header" title="Drag to move · Click to show keywords">
        <div class="meta">
          <div class="drag-hint">⠿ DRAG</div>
          <div class="title-row">
            <div class="title">Keywords</div>
            <span class="chevron" aria-hidden="true">▾</span>
          </div>
          <div class="status" id="status">${e.length} words · click tile</div>
        </div>
        <div class="header-actions">
          <button class="gear-btn" id="gear" title="Feature settings" type="button">⚙</button>
          <button class="clear-btn" id="clear" title="Clear highlights" type="button">Clear</button>
        </div>
      </div>
      <div class="prefs-panel" id="prefs">
        <div class="prefs-heading">Page highlights</div>
        <label class="pref-row">
          <span>Sticky notes</span>
          <span class="switch">
            <input type="checkbox" id="pref-sticky" />
            <span class="switch-slider"></span>
          </span>
        </label>
        <div class="prefs-heading">Selection tooltip</div>
        <label class="pref-row">
          <span>Save Highlight</span>
          <span class="switch">
            <input type="checkbox" id="pref-save" />
            <span class="switch-slider"></span>
          </span>
        </label>
        <label class="pref-row">
          <span>AI Summary</span>
          <span class="switch">
            <input type="checkbox" id="pref-ai" />
            <span class="switch-slider"></span>
          </span>
        </label>
        <label class="pref-row">
          <span>Summarize Page</span>
          <span class="switch">
            <input type="checkbox" id="pref-page" />
            <span class="switch-slider"></span>
          </span>
        </label>
      </div>
      <div class="word-panel" id="words">
        <div class="hint">Click a word for summary</div>
      </div>
    </div>
  `;const p=r.getElementById("tile"),a=r.getElementById("header"),s=r.getElementById("gear"),m=r.getElementById("clear"),i=r.getElementById("words"),c=r.getElementById("pref-sticky"),d=r.getElementById("pref-save"),f=r.getElementById("pref-ai"),h=r.getElementById("pref-page"),g=()=>{const u=Te??t;c.checked=!!u.stickyNotes,d.checked=!!u.saveHighlight,f.checked=!!u.aiSummary,h.checked=!!u.summarizePage,s.classList.toggle("active",n),p.classList.toggle("prefs-open",n)},v=u=>{o=!!u&&e.length>0,o&&(n=!1,g()),p.classList.toggle("open",o)};g(),nt(C,a),ot(u=>{u&&C&&V(C,u.left,u.top)}),s.addEventListener("click",u=>{u.stopPropagation(),n=!n,n&&v(!1),g()});const x=(u,w)=>{u.addEventListener("change",y=>{y.stopPropagation(),ee.onFeaturePatch({[w]:u.checked})}),u.addEventListener("click",y=>y.stopPropagation())};x(c,"stickyNotes"),x(d,"saveHighlight"),x(f,"aiSummary"),x(h,"summarizePage");for(const u of e){const w=D[u.colorIndex%D.length],y=document.createElement("button");y.type="button",y.className="chip",y.textContent=u.term,y.style.background=w.bg,y.style.borderColor=w.border,y.style.color=w.text,y.addEventListener("click",T=>{T.stopPropagation();const A=u.term.toLowerCase(),H=document.querySelector(`mark.${_}[data-aka-key="${CSS.escape(A)}"]`);H?(H.scrollIntoView({behavior:"smooth",block:"center"}),se(u,H)):se(u,C)}),i.appendChild(y)}a.addEventListener("click",u=>{var T;if(C._akaSkipNextHeaderClick)return;const y=u.target;y===m||m.contains(y)||y===s||s.contains(y)||(T=r.getElementById("prefs"))!=null&&T.contains(y)||e.length&&(n=!1,g(),v(!o))}),m.addEventListener("click",u=>{u.stopPropagation(),te();const w=r.getElementById("status");w&&(w.textContent="Cleared"),v(!1),O()}),document.documentElement.appendChild(C)}function Ie(e){if(O(),te(),j.clear(),de(),Te=e,!e.keywordsTile&&!e.stickyNotes)return;const t=Q(4e4),o=Ye(t,8);o.forEach(n=>{j.set(n.term.toLowerCase(),n)}),e.keywordsTile&&rt(o,e),e.stickyNotes&&Je()}function at(){O(),te(),j.clear(),de()}function it(){O()}function st(e){return e.some(t=>{var o;return t===C||t===E||t instanceof Element&&(((o=t.classList)==null?void 0:o.contains(_))||t.id===q||t.id===W)})}const ct="aka-root";function oe(){var e;try{return!!((e=chrome.runtime)!=null&&e.id)}catch{return!1}}let z=null,$=null,K=null,I=null;async function be(){return z=await F({type:M.PREFS_GET}),z}function ne(){return(z==null?void 0:z.featurePrefs)??Ae}Xe({isContextValid:oe,onSaveHighlight:async e=>{await F({type:M.SAVE_HIGHLIGHT,text:e,url:location.href,title:document.title}),N("Highlight saved")},onFeaturePatch:async e=>{const t={...ne(),...e};z=await F({type:M.PREFS_SET,prefs:{featurePrefs:t}}),ce()}});function lt(){$||($=document.createElement("div"),$.id=ct,$.style.all="initial",$.style.position="fixed",$.style.zIndex="2147483646",$.style.top="0",$.style.left="0",document.documentElement.appendChild($),K=$.attachShadow({mode:"open"}))}function Z(e=!0){var t;if(K&&(K.innerHTML=""),!!e)try{(t=window.getSelection())==null||t.removeAllRanges()}catch{}}function Me(e){const t=["input","textarea","select","[contenteditable]","[role='textbox']","[role='searchbox']","[role='combobox']","[aria-multiline='true']"].join(",");return e.some(o=>o instanceof HTMLElement&&(o.isContentEditable||!!o.closest(t)))}function dt(e,t,o){if(lt(),!K)return;const n=ne(),r=[];n.saveHighlight&&r.push('<button data-action="save" class="btn primary">Save Highlight</button>'),n.aiSummary&&r.push('<button data-action="summarize" class="btn">AI Summary</button>'),n.summarizePage&&r.push('<button data-action="page" class="btn">Summarize Page</button>'),r.length&&(K.innerHTML=`
    <style>
      :host { all: initial; }
      .tip {
        position: fixed;
        left: ${Math.min(e,window.innerWidth-340)}px;
        top: ${Math.min(t,window.innerHeight-56)}px;
        display: flex; gap: 6px; flex-wrap: wrap;
        padding: 8px; border-radius: 12px;
        background: rgba(255,255,255,0.92);
        backdrop-filter: blur(10px);
        box-shadow: 0 10px 30px rgba(15,23,42,0.18);
        border: 1px solid rgba(148,163,184,0.35);
        font-family: "Source Sans 3", Segoe UI, sans-serif;
      }
      .tip.dark {
        background: rgba(30,41,59,0.94);
        border-color: rgba(71,85,105,0.6);
      }
      .btn {
        border: 0; border-radius: 8px; padding: 6px 10px;
        font-size: 12px; font-weight: 600; cursor: pointer;
        background: #e2e8f0; color: #0f172a;
      }
      .btn.primary { background: #3b82f6; color: white; }
      .btn:hover { filter: brightness(0.96); }
      .tip.dark .btn { background: #475569; color: #f8fafc; }
      .tip.dark .btn.primary { background: #3b82f6; }
    </style>
    <div class="tip ${document.documentElement.dataset.akaTheme==="dark"?"dark":""}">
      ${r.join("")}
    </div>
  `,K.querySelectorAll("button").forEach(l=>{l.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation();const a=l.dataset.action;pt(a??"",o)})}))}async function pt(e,t){if(Z(),!!oe()){if(e==="save"){try{await F({type:M.SAVE_HIGHLIGHT,text:t,url:location.href,title:document.title}),N("Highlight saved")}catch(o){N(o instanceof Error?o.message:"Save failed")}return}if(e==="summarize"){const n=t.trim().split(/\s+/).filter(Boolean).length<=12?"explain":"summarize";let r=Se(t,2500);r&&P(r)&&(r=""),xe({title:Ge(t,56),focusLabel:t,text:t,selectedText:t,pageContext:r||void 0,action:n});return}if(e==="page"){const o=Q(4e4)||t;xe({title:"Page Summary",focusLabel:document.title||"This page",text:o,action:"page_summary"})}}}function xe(e){var k,L,R;const{title:t,focusLabel:o,text:n,selectedText:r,pageContext:l,action:p}=e;X(),I=document.createElement("div"),I.style.all="initial",I.style.position="fixed",I.style.inset="0",I.style.zIndex="2147483647";const a=I.attachShadow({mode:"open"});document.documentElement.appendChild(I);const s=crypto.randomUUID(),m=p==="summarize"||p==="explain"||p==="page_summary";a.innerHTML=`
    <style>
      .backdrop {
        position: fixed; inset: 0; background: rgba(15,23,42,0.45);
        display: grid; place-items: center; padding: 24px;
        font-family: "Source Sans 3", Segoe UI, sans-serif;
      }
      .card {
        width: min(560px, 100%); max-height: min(70vh, 640px);
        overflow: auto; border-radius: 16px; padding: 20px;
        background: #f8fafc; color: #0f172a;
        box-shadow: 0 20px 50px rgba(15,23,42,0.25);
      }
      .card.dark { background: #1e293b; color: #e2e8f0; }
      .header {
        display: flex; align-items: flex-start; justify-content: space-between;
        gap: 12px; margin-bottom: 6px;
      }
      h2 { margin: 0; flex: 1; font-size: 18px; line-height: 1.3; word-break: break-word; }
      .focus {
        display: ${m?"block":"none"};
        margin: 0 0 10px; padding: 8px 10px; border-radius: 8px;
        background: #e2e8f0; color: #0f172a; font-size: 13px; font-weight: 600;
        line-height: 1.4; white-space: pre-wrap; word-break: break-word;
      }
      .card.dark .focus { background: #334155; color: #e2e8f0; }
      .meta { font-size: 12px; opacity: 0.7; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
      .body { line-height: 1.6; font-size: 14px; word-break: break-word; }
      .body h1, .body h2, .body h3, .body h4 {
        margin: 12px 0 6px 0; font-size: 15px; font-weight: 700; color: inherit;
      }
      .body h1 { font-size: 17px; }
      .body h2 { font-size: 16px; }
      .body p { margin: 0 0 10px 0; }
      .body p:last-child { margin-bottom: 0; }
      .body ul, .body ol { margin: 6px 0 10px 0; padding-left: 22px; }
      .body li { margin-bottom: 4px; }
      .body code {
        background: rgba(0,0,0,0.06); padding: 2px 6px; border-radius: 4px;
        font-family: ui-monospace, SFMono-Regular, monospace; font-size: 13px;
      }
      .card.dark .body code { background: rgba(255,255,255,0.12); color: #f1f5f9; }
      .body pre {
        background: rgba(0,0,0,0.05); padding: 12px; border-radius: 8px;
        overflow-x: auto; font-family: ui-monospace, SFMono-Regular, monospace; font-size: 13px; margin: 10px 0;
      }
      .card.dark .body pre { background: rgba(0,0,0,0.35); color: #f1f5f9; }
      .body strong { font-weight: 700; color: inherit; }
      .body blockquote {
        border-left: 3px solid #3b82f6; padding-left: 12px; margin: 10px 0; opacity: 0.9;
      }
      .header-actions { display: flex; align-items: center; gap: 8px; }
      .actions { display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap; }
      button {
        border: 0; border-radius: 8px; padding: 8px 12px;
        font-weight: 600; cursor: pointer; background: #e2e8f0; color: #0f172a;
      }
      button.primary { background: #3b82f6; color: white; }
      button.copy-top {
        width: 30px; height: 30px; padding: 0; display: inline-grid; place-items: center;
      }
      button.copy-top svg { width: 15px; height: 15px; stroke: currentColor; fill: none; stroke-width: 1.8; }
      button.save { background: #fbbf24; color: #0f172a; }
      button.like { background: #059669; color: white; }
      button.close-x {
        flex-shrink: 0; width: 30px; height: 30px; border-radius: 50%; padding: 0;
        border: 1px solid #cbd5e1; background: #f1f5f9; color: #64748b;
        font-size: 18px; line-height: 1; font-weight: 500;
        display: flex; align-items: center; justify-content: center;
        transition: background 0.15s, border-color 0.15s, color 0.15s;
      }
      button.close-x:hover {
        background: rgba(244,63,94,0.12); border-color: rgba(244,63,94,0.35); color: #e11d48;
      }
      .card.dark button.close-x {
        background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.1);
        color: rgba(148,163,184,0.85);
      }
      .card.dark button.close-x:hover {
        background: rgba(244,63,94,0.15); border-color: rgba(244,63,94,0.3); color: #f43f5e;
      }
      button:disabled { opacity: 0.5; cursor: default; }
      .feedback { display: none; gap: 8px; margin-top: 12px; flex-wrap: wrap; align-items: center; }
      .feedback.visible { display: flex; }
      .feedback-note { font-size: 12px; opacity: 0.7; display: none; }
      .feedback-note.visible { display: inline; }
    </style>
    <div class="backdrop">
      <div class="card ${document.documentElement.dataset.akaTheme==="dark"?"dark":""}">
        <div class="header">
          <h2>${Y(t)}</h2>
          <div class="header-actions">
            <button type="button" class="copy-top" id="copy" aria-label="Copy response" title="Copy">
              <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"></rect><path d="M15 9V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h4"></path></svg>
            </button>
            <button type="button" class="close-x" id="close" aria-label="Close" title="Close">&times;</button>
          </div>
        </div>
        <div class="focus" id="focus">${Y(o)}</div>
        <div class="meta" id="meta">Generating…</div>
        <div class="body" id="body"></div>
        <div class="feedback" id="feedback">
          <button class="like" id="like">👍 Like</button>
          <span class="feedback-note" id="feedback-note">Liked</span>
        </div>
        <div class="actions">
          <button class="save" id="save">Save</button>
        </div>
      </div>
    </div>
  `;const i=a.getElementById("body"),c=we(i),d=a.getElementById("meta"),f=a.getElementById("feedback"),h=a.getElementById("feedback-note"),g=a.getElementById("like"),v=a.getElementById("save");let x="",u=!1,w=!1;const y=b=>{c.render(ke.createElement(ve,null,b))},T=()=>{const b=(x||i.textContent||"").trim(),S=(r||o||"").trim();return S&&b?`${S}

${b}`:b||S};(k=a.getElementById("close"))==null||k.addEventListener("click",X),(L=a.querySelector(".backdrop"))==null||L.addEventListener("click",b=>{b.target===b.currentTarget&&X()}),(R=a.getElementById("copy"))==null||R.addEventListener("click",()=>{navigator.clipboard.writeText(T()),N("Copied")}),v.addEventListener("click",()=>{if(w)return;const b=T().trim();if(!b){N("Nothing to save yet");return}(async()=>{v.disabled=!0;try{await F({type:M.SAVE_HIGHLIGHT,text:b,url:location.href,title:document.title}),w=!0,v.textContent="Saved!",N("Highlight saved")}catch(S){v.disabled=!1,N(S instanceof Error?S.message:"Save failed")}})()});async function A(){if(u)return;const b=(x||i.textContent||"").slice(0,200);if(b.trim()){u=!0,g.disabled=!0;try{await F({type:M.PERSONALIZATION_FEEDBACK,accepted:!0,action:p,textPreview:b}),h.classList.add("visible"),N("Liked — preferences updated")}catch(S){u=!1,g.disabled=!1,N(S instanceof Error?S.message:"Feedback failed")}}}g.addEventListener("click",()=>void A());const H=b=>{if(b.requestId===s){if(b.type===M.AI_STREAM_CHUNK&&b.chunk){if(x.length||(d.textContent="Streaming…"),x+=b.chunk,P(x)&&x.length>120){x="Could not produce a clean summary for this selection. Try again.",y(x),d.textContent="Filtered page chrome";return}y(x)}b.type===M.AI_STREAM_DONE&&(b.error?d.textContent=b.error:b.envelope?(d.textContent=`${b.envelope.latencyMs??0}ms`,f.classList.add("visible")):(d.textContent="Done",f.classList.add("visible")),chrome.runtime.onMessage.removeListener(H))}};chrome.runtime.onMessage.addListener(H),F({type:M.AI_STREAM,requestId:s,action:p,text:n,selectedText:r,pageContext:l,pageTitle:document.title,url:location.href}).catch(b=>{d.textContent=b instanceof Error?b.message:"AI failed"})}function X(){I==null||I.remove(),I=null}function N(e){const t=document.createElement("div");t.textContent=e,Object.assign(t.style,{position:"fixed",bottom:"24px",right:"24px",zIndex:"2147483647",background:"#0f172a",color:"#fff",padding:"10px 14px",borderRadius:"10px",fontFamily:"Segoe UI, sans-serif",fontSize:"13px",boxShadow:"0 8px 24px rgba(0,0,0,0.25)"}),document.documentElement.appendChild(t),setTimeout(()=>t.remove(),2200)}function ut(e){if(!oe())return;const t=e.composedPath();if(Me(t)){Z(!1);return}if(st(t)||t.some(r=>r===$||r===I))return;const o=window.getSelection(),n=(o==null?void 0:o.toString().trim())??"";if(!n||n.length<2){Z();return}dt(e.clientX+8,e.clientY+8,n)}function ft(e){Me(e.composedPath())||e.key==="Escape"&&(Z(),X(),it())}function mt(){const e=(z==null?void 0:z.theme)??"light";let t=e;e==="system"&&(t=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"),document.documentElement.dataset.akaTheme=t}function ce(){mt(),Ie(ne())}async function gt(){if(oe()){try{chrome.storage.local.remove(["hs_keyword_cache_v1","aka_keyword_cache_v1"],()=>{var e;try{(e=chrome.runtime)==null||e.lastError}catch{}})}catch{}try{await be()}catch{z=null}ce(),document.addEventListener("mouseup",ut),document.addEventListener("keydown",ft);try{chrome.storage.onChanged.addListener((e,t)=>{try{if(t!=="local")return;(e.theme||e.hs_feature_prefs)&&be().then(()=>ce())}catch{}})}catch{}}}gt();let ye=location.href;setInterval(()=>{location.href!==ye&&(ye=location.href,at(),Ie(ne()))},1500);
//# sourceMappingURL=index.ts-DC-fNqTo.js.map
