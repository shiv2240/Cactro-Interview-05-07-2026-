import{g as we}from"./marked.esm-gqIbqwO3.js";import{s as A,M as I,D as ke}from"./protocol-D3q8XD41.js";function j(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const se=["script","style","noscript","svg","iframe","canvas","nav","header","footer","aside","form","button","input","select","textarea","[role='navigation']","[role='banner']","[role='contentinfo']","[role='search']","[role='complementary']","[aria-hidden='true']",".mw-jump-link",".mw-jump-links","#mw-navigation","#mw-panel","#mw-head","#mw-page-base","#mw-head-base","#siteNotice","#contentSub","#jump-to-nav","#vector-toc","#vector-main-menu","#vector-page-tools","#vector-sticky-header","#p-lang-btn","#p-personal","#p-views","#p-namespaces","#p-cactions","#p-search",".vector-header",".vector-header-container",".vector-sticky-header",".vector-toc",".vector-toc-landmark",".vector-page-toolbar",".vector-page-toolbar-container",".vector-menu",".vector-dropdown",".vector-column-start",".vector-column-end",".mw-portlet",".mw-indicators",".mw-editsection",".mw-cite-backlink",".noprint",".navbox",".vertical-navbox",".sidebar",".sistersitebox","#toc",".toc",".mw-table-of-contents",".toccolours",".site-nav",".site-header",".site-footer","#aka-root","#aka-keyword-tile-root","#aka-keyword-popup-root","#hs-ai-modal-root","#hs-keyword-tile-root","#hs-keyword-popup-root"].join(","),K=new Set("search user menu article talk language watch edit contents jump wikipedia wikimedia commons portal help login log sign create account donate tools appearance hide show more less read view history main page random page about disclaimers contact download print share cite references notes external links see also navigation sidebar toolbar footer header cookie cookies privacy subscribe newsletter follow toggle subsection".split(/\s+/)),ve=/jump to content|jump to navigation|jump to search|main menu|create account|log[\s-]?in|contents\s*hide|toggle\s+\w+\s+subsection|user menu|donate\b|from wikipedia,? the free encyclopedia|languages?\s*$|add languages|appearance\b|vector-toc|edit links|view history|\(\s*top\s*\)/i;function Ee(){return document.querySelector("#mw-content-text .mw-parser-output")||document.querySelector("#mw-content-text")||document.querySelector("#bodyContent")||document.querySelector("#content")||document.querySelector("article")||document.querySelector("[role='main']")||document.querySelector("main")||document.body}function Ce(e){return e.replace(/[ \t\f\v]+/g," ").replace(/\n{3,}/g,`

`).trim()}function M(e){const t=e.trim();if(!t||ve.test(t))return!0;const o=t.toLowerCase();if(/^(search|user menu|article|talk|language|watch|edit|contents|donate|log in|create account)\b/.test(o)||/\btoggle\b/i.test(t)&&/\bsubsection\b/i.test(t))return!0;const n=o.match(/[a-z][a-z0-9-]{2,}/g)||[];if(n.length===0)return!0;let r=0;for(const c of n)K.has(c)&&r++;return r>=3&&n.length<=40||r>=5||n.length>=8&&r/n.length>=.45}function X(e){const t=e.split(/\r?\n/),o=[];for(const r of t){const c=r.trim();c&&(M(c)||c.length<3||o.push(c))}let n=o.join(`
`);return n=n.replace(/Jump to (content|search|navigation)[.\s]*/gi,"").replace(/\bFrom Wikipedia,? the free encyclopedia\b/gi,"").replace(/\bContents\s*hide\b/gi,"").replace(/\bToggle \w+ subsection\b/gi,"").replace(/\bCreate account\b/gi,"").replace(/\bLog in\b/gi,"").replace(/\bMain menu\b/gi,"").replace(/\bDonate\b/gi,""),Ce(n)}function Y(e=4e4){var r;const t=Ee();if(!t)return"";let o="";try{const c=t.cloneNode(!0);try{c.querySelectorAll(se).forEach(l=>l.remove())}catch{}o=c.innerText||c.textContent||""}catch{o=((r=document.body)==null?void 0:r.innerText)||""}let n=X(o);if(n.length<40){const c=document.querySelector("#mw-content-text .mw-parser-output");if(c&&c!==t)try{const l=c.cloneNode(!0);l.querySelectorAll(se).forEach(a=>a.remove()),n=X(l.innerText||l.textContent||"")}catch{}}return n.length>e&&(n=`${n.slice(0,e)}…`),n}function ge(e,t,o=220){const n=t??Y(12e3);if(!n||!e.trim())return"";const r=new RegExp(`\\b${e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}\\b`,"i"),l=n.split(new RegExp("(?<=[.!?])\\s+|\\n+")).map(a=>a.trim()).filter(a=>a.length>=24&&a.length<=420).filter(a=>r.test(a)).filter(a=>!M(a))[0];return l?l.slice(0,o):""}function me(e,t=2500){const o=Y(12e3);if(!o)return"";const n=e.trim();if(!n)return o.slice(0,t);const r=ge(n,o,400);if(r){const s=o.toLowerCase().indexOf(r.toLowerCase().slice(0,40));if(s>=0){const d=Math.floor((t-r.length)/2),m=Math.max(0,s-Math.max(d,200)),g=Math.min(o.length,m+t);let h=o.slice(m,g);return M(h)?r:(m>0&&(h=`…${h}`),g<o.length&&(h=`${h}…`),X(h)||r)}return r}const l=o.toLowerCase().indexOf(n.toLowerCase());if(l<0){const s=o.slice(0,t);return M(s)?"":s}const a=Math.floor((t-n.length)/2),i=Math.max(0,l-a),f=Math.min(o.length,l+n.length+a);let u=o.slice(i,f);return u=X(u),!u||M(u)?"":(i>0&&(u=`…${u}`),f<o.length&&(u=`${u}…`),u)}function Se(e,t=48){const o=e.trim().replace(/\s+/g," ");return o.length<=t?o:`${o.slice(0,Math.max(1,t-1))}…`}function he(e,t){const o=(document.title||"this page").trim();return`Key term “${e}” on “${o}”. Open again for a full Meaning / On this page / Why it matters summary.`}const B=[{bg:"#fff59d",border:"#f0e68c",text:"#3d3420"},{bg:"#f8bbd0",border:"#f0a8c0",text:"#4a2030"},{bg:"#bbdefb",border:"#a8d0f0",text:"#1e3048"},{bg:"#c8e6c9",border:"#b5d8b8",text:"#1e3a28"},{bg:"#ffe0b2",border:"#f0d0a0",text:"#4a3020"},{bg:"#e1bee7",border:"#d0aee0",text:"#3a2048"},{bg:"#b2dfdb",border:"#a0d0cc",text:"#1e3a38"},{bg:"#ffccbc",border:"#f0b8a8",text:"#4a2820"}],te="hs_tile_position",ce=new Set("a an the and or but if in on at to for of as is was are were be been being this that these those it its with from by into over after before about between not no yes you your we they he she his her their our my me him them us will would can could should may might must shall do does did done having have has had what when where which who how why all any each few more most other some such than too very just also only then there here using use used via per etc http https www com".split(/\s+/)),D="aka-keyword-tile-root",W="aka-keyword-popup-root",H="aka-kw-mark",le=120,q=new Map;let T=null,E=null,V=null,N=null,be=null,J={onSaveHighlight:async()=>{},onFeaturePatch:async()=>{},isContextValid:()=>{var e;try{return!!((e=chrome.runtime)!=null&&e.id)}catch{return!1}}};function Te(e){J=e}function re(){return J.isContextValid()}function xe(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Le(e,t=8){const o=new Map,n=String(e||"").match(/[A-Za-z][A-Za-z0-9+.#-]{2,}/g)||[];for(const a of n){const i=a.toLowerCase();ce.has(i)||K.has(i)||i.length<4||i.length>40||o.set(i,(o.get(i)??0)+1)}for(const a of String(document.title||"").toLowerCase().split(/[^a-z0-9+.#-]+/).filter(Boolean))a.length>=4&&!ce.has(a)&&!K.has(a)&&o.set(a,(o.get(a)??0)+3);const r=[...o.entries()].sort((a,i)=>i[1]-a[1]||i[0].length-a[0].length).slice(0,t*3),c=[],l=new Set;for(let a=0;a<r.length;a++){const i=r[a][0];if(c.length>=t)break;if(l.has(i)||K.has(i))continue;const f=new RegExp(`\\b(${xe(i)})\\b`,"i"),u=String(e||"").match(f),s=(u==null?void 0:u[1])??i;if(K.has(s.toLowerCase()))continue;l.add(i);const d=ge(s,e,180),m=d&&!M(d)?d:he(s);c.push({term:s,summary:m,colorIndex:a%B.length})}return c}function Z(){document.querySelectorAll(`mark.${H}`).forEach(e=>{const t=e.parentNode;t&&(t.replaceChild(document.createTextNode(e.textContent||""),e),t.normalize())})}function de(e){var o;if(!e||e.nodeType!==1)return!0;const t=e.tagName;return!!(/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|SELECT|OPTION|SVG|CANVAS|IFRAME|CODE|PRE|KBD|SAMP)$/i.test(t)||e.isContentEditable||e.id===D||e.id===W||e.id==="aka-root"||(o=e.closest)!=null&&o.call(e,`#${D}, #${W}, #aka-root, mark.${H}`))}function Ie(e){var a;if(Z(),q.size===0)return 0;const t=[...q.values()].map(i=>i.term).filter(Boolean).sort((i,f)=>f.length-i.length);if(!t.length)return 0;const o=new RegExp(`(${t.map(i=>{const f=xe(i);return!/\s/.test(i)&&i.length<=12?`\\b${f}\\b`:f}).join("|")})`,"gi"),n=document.querySelector("article")||document.querySelector("main")||document.body;if(!n||de(n))return 0;const r=document.createTreeWalker(n,NodeFilter.SHOW_TEXT,{acceptNode(i){var u;if(!((u=i.nodeValue)!=null&&u.trim()))return NodeFilter.FILTER_REJECT;const f=i.parentElement;return!f||de(f)||f.closest(`mark.${H}`)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}}),c=[];for(;r.nextNode();)c.push(r.currentNode);let l=0;for(const i of c){if(l>=le)break;const f=i.nodeValue??"";if(o.lastIndex=0,!o.test(f)){o.lastIndex=0;continue}o.lastIndex=0;const u=document.createDocumentFragment();let s=0,d,m=!1;for(;(d=o.exec(f))!==null&&!(l>=le);){const g=d[0],h=g.toLowerCase(),y=q.get(h);if(d.index>s&&u.appendChild(document.createTextNode(f.slice(s,d.index))),!y){u.appendChild(document.createTextNode(g)),s=d.index+g.length;continue}const x=B[y.colorIndex%B.length],p=document.createElement("mark");p.className=H,p.dataset.akaKey=h,p.textContent=g,p.style.cssText=`
        background: ${x.bg};
        color: inherit;
        border: 1px solid ${x.border};
        border-radius: 2px;
        padding: 0 3px;
        margin: 0 1px;
        cursor: pointer;
        box-shadow: none;
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
      `,p.title="Click for context · Esc to close",p.addEventListener("click",v=>{v.preventDefault(),v.stopPropagation(),oe(y,p)}),u.appendChild(p),m=!0,l++,s=d.index+g.length}!m&&s===0||(s<f.length&&u.appendChild(document.createTextNode(f.slice(s))),(a=i.parentNode)==null||a.replaceChild(u,i))}return l}function F(){var e;V&&(V(),V=null),E==null||E.remove(),E=null,(e=document.getElementById(W))==null||e.remove()}function Me(e,t){return`${e}

${t}`.trim()}function $e(e,t){var y;if(!e.isConnected)return;const o=10,n=12,r=Math.min(360,Math.max(240,document.documentElement.clientWidth-24)),c=(y=e.shadowRoot)==null?void 0:y.querySelector(".card"),l=(c==null?void 0:c.offsetHeight)||220,a=window.scrollX||0,i=window.scrollY||0;let f;if(t&&document.contains(t))f=t.getBoundingClientRect();else{const x=document.getElementById(D);f=(x==null?void 0:x.getBoundingClientRect())||{top:80,bottom:110,left:window.innerWidth-380,width:0,height:0}}const u=window.innerHeight-f.bottom;let s;u>=Math.min(l+o,140)?s=f.bottom+o:s=f.top-l-o;let d=f.left+(f.width||0)/2-r/2;const m=Math.max(document.documentElement.scrollWidth,document.documentElement.clientWidth);let g=d+a;g=Math.max(n,Math.min(g,m-r-n));const h=Math.max(n,s+i);e.style.top=`${h}px`,e.style.left=`${g}px`,e.style.width=`${r}px`}function oe(e,t){var P;F(),E=document.createElement("div"),E.id=W,E.style.cssText="position:absolute;z-index:2147483647;opacity:0;transform:translateY(6px) scale(0.97);";const o=E.attachShadow({mode:"open"}),n=B[e.colorIndex%B.length],r=e.summary&&!M(e.summary)?e.summary:he(e.term);let c=r;const l=()=>Me(e.term,c),a=e.term.toLowerCase();let i=t&&document.contains(t)?t:null;!i&&a&&(i=document.querySelector(`mark.${H}[data-aka-key="${CSS.escape(a)}"]`));const f=crypto.randomUUID();o.innerHTML=`
    <style>
      .card {
        font-family: "Segoe UI", system-ui, sans-serif;
        width: 100%; background: #fffef8; border: 1px solid #e8e4d8;
        border-radius: 10px; box-shadow: 0 4px 16px rgba(60,50,30,0.12);
        overflow: hidden; color: #3d3420;
      }
      .accent { height: 6px; background: ${n.bg}; border-bottom: 1px solid ${n.border}; }
      .head {
        display: flex; align-items: flex-start; justify-content: space-between;
        gap: 10px; padding: 12px 14px 8px;
      }
      .term {
        font-size: 16px; font-weight: 780; letter-spacing: -0.02em; color: #2c2416;
        line-height: 1.25; word-break: break-word;
      }
      .badge {
        display: inline-block; margin-top: 6px; font-size: 10px; font-weight: 650;
        letter-spacing: 0.03em; text-transform: uppercase; padding: 3px 8px;
        border-radius: 4px; background: ${n.bg}; border: 1px solid ${n.border};
        color: ${n.text};
      }
      .status {
        margin: 0 14px 6px; font-size: 11px; color: #8a8272;
      }
      .close {
        border: 1px solid #e0dccf; background: #f7f5ee; color: #5c5548;
        width: 28px; height: 28px; border-radius: 6px; cursor: pointer; font-size: 16px;
      }
      .close:hover { background: #efece3; color: #9a3412; }
      .body {
        padding: 2px 14px 10px; max-height: min(360px, 58vh); overflow: auto;
        font-size: 13px; line-height: 1.55; color: #4a4336; white-space: pre-wrap;
      }
      .actions {
        display: flex; align-items: center; gap: 8px;
        padding: 10px 14px 12px; border-top: 1px solid #ebe6da; background: #faf8f1;
      }
      .abtn {
        display: inline-flex; align-items: center; gap: 5px;
        border: 1px solid #e0dccf; background: #fff; color: #3d3420;
        border-radius: 6px; padding: 7px 11px; font-size: 12px; font-weight: 650; cursor: pointer;
      }
      .abtn:hover { background: #f3f0e6; }
      .abtn-save { background: #fff59d; border-color: #f0e68c; }
      .abtn-save:hover { background: #fff176; }
      .abtn-save:disabled {
        background: #e8f5e9; border-color: #c8e6c9; color: #2e7d32; cursor: default;
      }
      .hint { margin-left: auto; font-size: 10.5px; color: #8a8272; }
      .kbd {
        font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 10px;
        padding: 2px 6px; border-radius: 4px; border: 1px solid #e0dccf; background: #fff;
      }
    </style>
    <div class="card">
      <div class="accent"></div>
      <div class="head">
        <div>
          <div class="term" id="term">${j(e.term)}</div>
          <span class="badge">Keyword summary</span>
        </div>
        <button class="close" type="button" aria-label="Close" title="Close (Esc)" id="close">&times;</button>
      </div>
      <div class="status" id="status">Generating insight…</div>
      <div class="body" id="body">Explaining “${j(e.term)}”…</div>
      <div class="actions">
        <button class="abtn abtn-save" type="button" id="save">Save</button>
        <button class="abtn" type="button" id="copy">Copy</button>
        <span class="hint"><span class="kbd">Esc</span> close</span>
      </div>
    </div>
  `;const u=o.getElementById("body"),s=o.getElementById("status");(P=o.getElementById("close"))==null||P.addEventListener("click",F);const d=o.getElementById("save"),m=o.getElementById("copy");m==null||m.addEventListener("click",()=>{var b;const k=()=>{if(!m)return;const S=m.innerHTML;m.textContent="Copied!",setTimeout(()=>{m.innerHTML=S},1400)},C=l(),$=()=>{const S=document.createElement("textarea");S.value=C,document.body.appendChild(S),S.select();try{document.execCommand("copy"),k()}catch{}S.remove()};(b=navigator.clipboard)!=null&&b.writeText?navigator.clipboard.writeText(C).then(k).catch($):$()}),d==null||d.addEventListener("click",()=>{if(!re()){window.location.reload();return}(async()=>{try{await J.onSaveHighlight(l()),d&&(d.disabled=!0,d.textContent="Saved!")}catch{d&&(d.textContent="Failed")}})()}),document.documentElement.appendChild(E);const g=()=>{(!i||!document.contains(i))&&a&&(i=document.querySelector(`mark.${H}[data-aka-key="${CSS.escape(a)}"]`)),E&&$e(E,i)};g(),requestAnimationFrame(()=>{E&&(E.style.transition="opacity 0.2s ease, transform 0.2s ease",E.style.opacity="1",E.style.transform="translateY(0) scale(1)",g())});const h=()=>g();window.addEventListener("resize",h);const y=k=>{const C=k.composedPath();!C.includes(E)&&!C.some($=>{var b;return $ instanceof Element&&((b=$.classList)==null?void 0:b.contains(H))})&&!C.some($=>$ instanceof Element&&$.id===D)&&F()};setTimeout(()=>document.addEventListener("mousedown",y,!0),0);let x="";const p=k=>{c=r,u.textContent=r,s.textContent=k},v=k=>{var C;if(k.requestId===f){if(k.type===I.AI_STREAM_CHUNK&&k.chunk){if(x+=k.chunk,M(x)&&x.length>80){p("Filtered page chrome — retry");return}c=x,u.textContent=x,s.textContent="Streaming…",g()}k.type===I.AI_STREAM_DONE&&(chrome.runtime.onMessage.removeListener(v),k.error?p(k.error):!x.trim()||M(x)?p("Done"):(c=x,u.textContent=x,s.textContent=(C=k.envelope)!=null&&C.latencyMs?`${k.envelope.latencyMs}ms`:"Done"),g())}};chrome.runtime.onMessage.addListener(v);let w=me(e.term,2500);w&&M(w)&&(w=""),A({type:I.AI_STREAM,requestId:f,action:"explain",text:e.term,selectedText:e.term,pageContext:w||void 0,pageTitle:document.title,url:location.href}).catch(k=>{p(k instanceof Error?k.message:"AI failed"),chrome.runtime.onMessage.removeListener(v)}),V=()=>{window.removeEventListener("resize",h),document.removeEventListener("mousedown",y,!0),chrome.runtime.onMessage.removeListener(v)}}function ze(e,t,o,n){const c=Math.max(8,window.innerWidth-o-8),l=Math.max(8,window.innerHeight-n-8);return{left:Math.min(Math.max(8,e),c),top:Math.min(Math.max(8,t),l)}}function U(e,t,o){const n=e.offsetWidth||210,r=e.offsetHeight||56,c=ze(t,o,n,r);return e.style.left=`${c.left}px`,e.style.top=`${c.top}px`,e.style.right="auto",e.style.bottom="auto",c}function Pe(e,t){if(re())try{chrome.storage.local.set({[te]:{left:e,top:t}},()=>{var o;try{(o=chrome.runtime)==null||o.lastError}catch{}})}catch{}}function Re(e){if(!re()){e(null);return}try{chrome.storage.local.get([te],t=>{var o;try{if((o=chrome.runtime)!=null&&o.lastError){e(null);return}const n=t==null?void 0:t[te];n&&typeof n.left=="number"&&typeof n.top=="number"?e({left:n.left,top:n.top}):e(null)}catch{e(null)}})}catch{e(null)}}function _e(e,t){let o=!1,n=!1,r=0,c=0,l=0,a=0;const i=5,f=s=>{var g,h;if(!o)return;const d=s.clientX-r,m=s.clientY-c;!n&&(Math.abs(d)>i||Math.abs(m)>i)&&(n=!0,e.classList.add("aka-dragging"),(h=(g=e.shadowRoot)==null?void 0:g.querySelector(".tile"))==null||h.classList.add("dragging"),t.style.cursor="grabbing"),n&&(s.preventDefault(),U(e,l+d,a+m))},u=s=>{var d,m,g;if(o){o=!1,e.classList.remove("aka-dragging"),(m=(d=e.shadowRoot)==null?void 0:d.querySelector(".tile"))==null||m.classList.remove("dragging"),t.style.cursor="grab",window.removeEventListener("pointermove",f,!0),window.removeEventListener("pointerup",u,!0),window.removeEventListener("pointercancel",u,!0);try{(g=t.releasePointerCapture)==null||g.call(t,s.pointerId)}catch{}if(n){const h=parseFloat(e.style.left)||0,y=parseFloat(e.style.top)||0,x=U(e,h,y);Pe(x.left,x.top),e._akaSkipNextHeaderClick=!0,setTimeout(()=>{e._akaSkipNextHeaderClick=!1},0)}}};t.addEventListener("pointerdown",s=>{var g,h;if(s.button!==0)return;const d=s.target;if((g=d==null?void 0:d.closest)!=null&&g.call(d,".gear-btn, .clear-btn, .prefs-panel, button, input, label, .chip, #list"))return;o=!0,n=!1,r=s.clientX,c=s.clientY;const m=e.getBoundingClientRect();l=m.left,a=m.top,U(e,l,a),(h=t.setPointerCapture)==null||h.call(t,s.pointerId),window.addEventListener("pointermove",f,!0),window.addEventListener("pointerup",u,!0),window.addEventListener("pointercancel",u,!0)}),N&&window.removeEventListener("resize",N),N=()=>{const s=parseFloat(e.style.left),d=parseFloat(e.style.top);Number.isFinite(s)&&Number.isFinite(d)&&U(e,s,d)},window.addEventListener("resize",N)}function ae(){var e;N&&(window.removeEventListener("resize",N),N=null),T==null||T.remove(),T=null,(e=document.getElementById(D))==null||e.remove()}function He(e,t){if(ae(),!e.length)return;let o=!1,n=!1;T=document.createElement("div"),T.id=D,T.style.cssText="all:initial;position:fixed;top:16px;right:16px;z-index:2147483645;";const r=T.attachShadow({mode:"open"}),c=document.documentElement.dataset.akaTheme==="dark"?"dark":"light";r.innerHTML=`
    <style>
      :host { all: initial; }
      .tile {
        font-family: "Segoe UI", system-ui, sans-serif;
        display: flex; flex-direction: column; width: 210px;
        border-radius: 10px; background: #fffef8; border: 1px solid #e8e4d8;
        box-shadow: 0 2px 8px rgba(60,50,30,0.08); color: #3d3420;
        user-select: none; overflow: hidden; touch-action: none;
      }
      :host(.aka-dragging) .tile, .tile.dragging {
        box-shadow: 0 6px 18px rgba(60,50,30,0.16); opacity: 0.96;
      }
      .header {
        display: flex; align-items: flex-start; gap: 8px;
        padding: 11px 12px; cursor: grab;
      }
      .header:hover { background: #faf7ef; }
      .header:active { cursor: grabbing; }
      .drag-hint {
        font-size: 9px; color: #a89f8c; letter-spacing: 0.08em; margin-bottom: 2px;
      }
      .meta { flex: 1; min-width: 0; }
      .title-row { display: flex; align-items: center; gap: 6px; }
      .title { font-size: 12px; font-weight: 650; color: #2c2416; }
      .chevron { font-size: 10px; color: #8a8272; margin-left: auto; transition: transform 0.18s; }
      .tile.open .chevron { transform: rotate(180deg); }
      .status { font-size: 11px; color: #6b6354; margin-top: 3px; line-height: 1.35; }
      .header-actions {
        display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0;
      }
      .gear-btn, .clear-btn {
        border: 1px solid #e0dccf; background: #f7f5ee; color: #5c5548;
        border-radius: 6px; cursor: pointer; outline: none; touch-action: auto;
      }
      .gear-btn { width: 26px; height: 26px; padding: 0; font-size: 13px; }
      .gear-btn.active { background: #ebe6da; border-color: #cfc8b6; }
      .clear-btn { padding: 3px 8px; font-size: 10.5px; font-weight: 600; }
      .clear-btn:disabled { opacity: 0.4; cursor: default; }
      .prefs-panel {
        display: none; flex-direction: column; gap: 8px;
        padding: 8px 10px 10px; border-top: 1px solid #ebe6da; touch-action: auto;
      }
      .tile.prefs-open .prefs-panel { display: flex; }
      .tile.prefs-open .word-panel { display: none !important; }
      .prefs-heading {
        font-size: 10px; font-weight: 700; letter-spacing: 0.06em;
        text-transform: uppercase; color: #8a8272; margin: 2px 0 0;
      }
      .pref-row {
        display: flex; align-items: center; justify-content: space-between;
        gap: 10px; font-size: 11.5px; font-weight: 550; color: #3d3420;
      }
      .switch { position: relative; width: 34px; height: 18px; flex-shrink: 0; }
      .switch input { opacity: 0; width: 0; height: 0; position: absolute; }
      .switch-slider {
        position: absolute; inset: 0; background: #d5cfbf; border-radius: 999px; cursor: pointer;
      }
      .switch-slider::before {
        content: ''; position: absolute; width: 14px; height: 14px; left: 2px; top: 2px;
        background: #fff; border-radius: 50%; transition: transform 0.15s;
        box-shadow: 0 1px 2px rgba(0,0,0,0.15);
      }
      .switch input:checked + .switch-slider { background: #5b8f3a; }
      .switch input:checked + .switch-slider::before { transform: translateX(16px); }
      .word-panel {
        display: none; flex-direction: column; gap: 6px;
        padding: 0 10px 10px; max-height: min(340px, 55vh); overflow: auto;
        border-top: 1px solid #ebe6da; padding-top: 8px; touch-action: auto;
      }
      .tile.open .word-panel { display: flex; }
      .hint { font-size: 10px; color: #8a8272; padding: 0 2px 2px; }
      .chip {
        display: block; width: 100%; text-align: left; font-size: 12px; font-weight: 600;
        padding: 7px 9px; border-radius: 6px; border: 1px solid transparent;
        cursor: pointer; outline: none; touch-action: auto;
      }
      .chip:hover { opacity: 0.9; }
      .tile[data-theme="dark"] {
        background: rgba(18,28,48,0.92); border-color: rgba(160,190,230,0.16);
        box-shadow: 0 8px 24px rgba(0,0,0,0.4); color: #e6eef8;
      }
      .tile[data-theme="dark"] .title { color: #e6eef8; }
      .tile[data-theme="dark"] .status, .tile[data-theme="dark"] .hint { color: #9db0c8; }
      .tile[data-theme="dark"] .drag-hint, .tile[data-theme="dark"] .prefs-heading { color: #7a8fa8; }
      .tile[data-theme="dark"] .gear-btn, .tile[data-theme="dark"] .clear-btn {
        border-color: rgba(160,190,230,0.18); background: rgba(30,42,68,0.9); color: #c5d4ef;
      }
      .tile[data-theme="dark"] .pref-row { color: #e6eef8; }
      .tile[data-theme="dark"] .header:hover { background: rgba(30,42,68,0.55); }
      .tile[data-theme="dark"] .switch-slider { background: #3a4a62; }
      .tile[data-theme="dark"] .switch input:checked + .switch-slider { background: #4ade80; }
    </style>
    <div class="tile" data-theme="${c}" id="tile">
      <div class="header" id="header" title="Drag to move · Click to show keywords">
        <div class="meta">
          <div class="drag-hint">⠿ DRAG</div>
          <div class="title-row">
            <div class="title">Keywords</div>
            <span class="chevron" aria-hidden="true">▾</span>
          </div>
          <div class="status" id="status">${e.length} words · click tile</div>
        </div>
        <div class="header-actions">
          <button class="gear-btn" id="gear" title="Feature settings" type="button">⚙</button>
          <button class="clear-btn" id="clear" title="Clear highlights" type="button">Clear</button>
        </div>
      </div>
      <div class="prefs-panel" id="prefs">
        <div class="prefs-heading">Page highlights</div>
        <label class="pref-row">
          <span>Sticky notes</span>
          <span class="switch">
            <input type="checkbox" id="pref-sticky" />
            <span class="switch-slider"></span>
          </span>
        </label>
        <div class="prefs-heading">Selection tooltip</div>
        <label class="pref-row">
          <span>Save Highlight</span>
          <span class="switch">
            <input type="checkbox" id="pref-save" />
            <span class="switch-slider"></span>
          </span>
        </label>
        <label class="pref-row">
          <span>AI Summary</span>
          <span class="switch">
            <input type="checkbox" id="pref-ai" />
            <span class="switch-slider"></span>
          </span>
        </label>
        <label class="pref-row">
          <span>Summarize Page</span>
          <span class="switch">
            <input type="checkbox" id="pref-page" />
            <span class="switch-slider"></span>
          </span>
        </label>
      </div>
      <div class="word-panel" id="words">
        <div class="hint">Click a word for summary</div>
      </div>
    </div>
  `;const l=r.getElementById("tile"),a=r.getElementById("header"),i=r.getElementById("gear"),f=r.getElementById("clear"),u=r.getElementById("words"),s=r.getElementById("pref-sticky"),d=r.getElementById("pref-save"),m=r.getElementById("pref-ai"),g=r.getElementById("pref-page"),h=()=>{const p=be??t;s.checked=!!p.stickyNotes,d.checked=!!p.saveHighlight,m.checked=!!p.aiSummary,g.checked=!!p.summarizePage,i.classList.toggle("active",n),l.classList.toggle("prefs-open",n)},y=p=>{o=!!p&&e.length>0,o&&(n=!1,h()),l.classList.toggle("open",o)};h(),_e(T,a),Re(p=>{p&&T&&U(T,p.left,p.top)}),i.addEventListener("click",p=>{p.stopPropagation(),n=!n,n&&y(!1),h()});const x=(p,v)=>{p.addEventListener("change",w=>{w.stopPropagation(),J.onFeaturePatch({[v]:p.checked})}),p.addEventListener("click",w=>w.stopPropagation())};x(s,"stickyNotes"),x(d,"saveHighlight"),x(m,"aiSummary"),x(g,"summarizePage");for(const p of e){const v=B[p.colorIndex%B.length],w=document.createElement("button");w.type="button",w.className="chip",w.textContent=p.term,w.style.background=v.bg,w.style.borderColor=v.border,w.style.color=v.text,w.addEventListener("click",P=>{P.stopPropagation();const k=p.term.toLowerCase(),C=document.querySelector(`mark.${H}[data-aka-key="${CSS.escape(k)}"]`);C?(C.scrollIntoView({behavior:"smooth",block:"center"}),oe(p,C)):oe(p,T)}),u.appendChild(w)}a.addEventListener("click",p=>{var P;if(T._akaSkipNextHeaderClick)return;const w=p.target;w===f||f.contains(w)||w===i||i.contains(w)||(P=r.getElementById("prefs"))!=null&&P.contains(w)||e.length&&(n=!1,h(),y(!o))}),f.addEventListener("click",p=>{p.stopPropagation(),Z();const v=r.getElementById("status");v&&(v.textContent="Cleared"),y(!1),F()}),document.documentElement.appendChild(T)}function ye(e){if(F(),Z(),q.clear(),ae(),be=e,!e.keywordsTile&&!e.stickyNotes)return;const t=Y(4e4),o=Le(t,8);o.forEach(n=>{q.set(n.term.toLowerCase(),n)}),e.keywordsTile&&He(o,e),e.stickyNotes&&Ie()}function Ae(){F(),Z(),q.clear(),ae()}function Ne(){F()}function Fe(e){return e.some(t=>{var o;return t===T||t===E||t instanceof Element&&(((o=t.classList)==null?void 0:o.contains(H))||t.id===D||t.id===W)})}const Be="aka-root";function Q(){var e;try{return!!((e=chrome.runtime)!=null&&e.id)}catch{return!1}}let R=null,z=null,O=null,L=null;async function pe(){return R=await A({type:I.PREFS_GET}),R}function ee(){return(R==null?void 0:R.featurePrefs)??ke}Te({isContextValid:Q,onSaveHighlight:async e=>{await A({type:I.SAVE_HIGHLIGHT,text:e,url:location.href,title:document.title}),_("Highlight saved")},onFeaturePatch:async e=>{const t={...ee(),...e};R=await A({type:I.PREFS_SET,prefs:{featurePrefs:t}}),ne()}});function De(){z||(z=document.createElement("div"),z.id=Be,z.style.all="initial",z.style.position="fixed",z.style.zIndex="2147483646",z.style.top="0",z.style.left="0",document.documentElement.appendChild(z),O=z.attachShadow({mode:"open"}))}function ie(){var e;O&&(O.innerHTML="");try{(e=window.getSelection())==null||e.removeAllRanges()}catch{}}function qe(e,t,o){if(De(),!O)return;const n=ee(),r=[];n.saveHighlight&&r.push('<button data-action="save" class="btn primary">Save Highlight</button>'),n.aiSummary&&r.push('<button data-action="summarize" class="btn">AI Summary</button>'),n.summarizePage&&r.push('<button data-action="page" class="btn">Summarize Page</button>'),r.length&&(O.innerHTML=`
    <style>
      :host { all: initial; }
      .tip {
        position: fixed;
        left: ${Math.min(e,window.innerWidth-340)}px;
        top: ${Math.min(t,window.innerHeight-56)}px;
        display: flex; gap: 6px; flex-wrap: wrap;
        padding: 8px; border-radius: 12px;
        background: rgba(255,255,255,0.92);
        backdrop-filter: blur(10px);
        box-shadow: 0 10px 30px rgba(15,23,42,0.18);
        border: 1px solid rgba(148,163,184,0.35);
        font-family: "Source Sans 3", Segoe UI, sans-serif;
      }
      .tip.dark {
        background: rgba(30,41,59,0.94);
        border-color: rgba(71,85,105,0.6);
      }
      .btn {
        border: 0; border-radius: 8px; padding: 6px 10px;
        font-size: 12px; font-weight: 600; cursor: pointer;
        background: #e2e8f0; color: #0f172a;
      }
      .btn.primary { background: #3b82f6; color: white; }
      .btn:hover { filter: brightness(0.96); }
      .tip.dark .btn { background: #475569; color: #f8fafc; }
      .tip.dark .btn.primary { background: #3b82f6; }
    </style>
    <div class="tip ${document.documentElement.dataset.akaTheme==="dark"?"dark":""}">
      ${r.join("")}
    </div>
  `,O.querySelectorAll("button").forEach(c=>{c.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation();const a=c.dataset.action;Oe(a??"",o)})}))}async function Oe(e,t){if(ie(),!!Q()){if(e==="save"){try{await A({type:I.SAVE_HIGHLIGHT,text:t,url:location.href,title:document.title}),_("Highlight saved")}catch(o){_(o instanceof Error?o.message:"Save failed")}return}if(e==="summarize"){const n=t.trim().split(/\s+/).filter(Boolean).length<=12?"explain":"summarize";let r=me(t,2500);r&&M(r)&&(r=""),ue({title:Se(t,56),focusLabel:t,text:t,selectedText:t,pageContext:r||void 0,action:n});return}if(e==="page"){const o=Y(4e4)||t;ue({title:"Page Summary",focusLabel:document.title||"This page",text:o,action:"page_summary"})}}}function ue(e){var k,C,$;const{title:t,focusLabel:o,text:n,selectedText:r,pageContext:c,action:l}=e;G(),L=document.createElement("div"),L.style.all="initial",L.style.position="fixed",L.style.inset="0",L.style.zIndex="2147483647";const a=L.attachShadow({mode:"open"});document.documentElement.appendChild(L);const i=crypto.randomUUID(),f=l==="summarize"||l==="explain"||l==="page_summary";a.innerHTML=`
    <style>
      .backdrop {
        position: fixed; inset: 0; background: rgba(15,23,42,0.45);
        display: grid; place-items: center; padding: 24px;
        font-family: "Source Sans 3", Segoe UI, sans-serif;
      }
      .card {
        width: min(560px, 100%); max-height: min(70vh, 640px);
        overflow: auto; border-radius: 16px; padding: 20px;
        background: #f8fafc; color: #0f172a;
        box-shadow: 0 20px 50px rgba(15,23,42,0.25);
      }
      .card.dark { background: #1e293b; color: #e2e8f0; }
      .header {
        display: flex; align-items: flex-start; justify-content: space-between;
        gap: 12px; margin-bottom: 6px;
      }
      h2 { margin: 0; flex: 1; font-size: 18px; line-height: 1.3; word-break: break-word; }
      .focus {
        display: ${f?"block":"none"};
        margin: 0 0 10px; padding: 8px 10px; border-radius: 8px;
        background: #e2e8f0; color: #0f172a; font-size: 13px; font-weight: 600;
        line-height: 1.4; white-space: pre-wrap; word-break: break-word;
      }
      .card.dark .focus { background: #334155; color: #e2e8f0; }
      .meta { font-size: 12px; opacity: 0.7; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
      .body { line-height: 1.6; font-size: 14px; word-break: break-word; }
      .body h1, .body h2, .body h3, .body h4 {
        margin: 12px 0 6px 0; font-size: 15px; font-weight: 700; color: inherit;
      }
      .body h1 { font-size: 17px; }
      .body h2 { font-size: 16px; }
      .body p { margin: 0 0 10px 0; }
      .body p:last-child { margin-bottom: 0; }
      .body ul, .body ol { margin: 6px 0 10px 0; padding-left: 22px; }
      .body li { margin-bottom: 4px; }
      .body code {
        background: rgba(0,0,0,0.06); padding: 2px 6px; border-radius: 4px;
        font-family: ui-monospace, SFMono-Regular, monospace; font-size: 13px;
      }
      .card.dark .body code { background: rgba(255,255,255,0.12); color: #f1f5f9; }
      .body pre {
        background: rgba(0,0,0,0.05); padding: 12px; border-radius: 8px;
        overflow-x: auto; font-family: ui-monospace, SFMono-Regular, monospace; font-size: 13px; margin: 10px 0;
      }
      .card.dark .body pre { background: rgba(0,0,0,0.35); color: #f1f5f9; }
      .body strong { font-weight: 700; color: inherit; }
      .body blockquote {
        border-left: 3px solid #3b82f6; padding-left: 12px; margin: 10px 0; opacity: 0.9;
      }
      .actions { display: flex; gap: 8px; margin-top: 16px; flex-wrap: wrap; }
      button {
        border: 0; border-radius: 8px; padding: 8px 12px;
        font-weight: 600; cursor: pointer; background: #e2e8f0; color: #0f172a;
      }
      button.primary { background: #3b82f6; color: white; }
      button.save { background: #fbbf24; color: #0f172a; }
      button.like { background: #059669; color: white; }
      button.close-x {
        flex-shrink: 0; width: 30px; height: 30px; border-radius: 50%; padding: 0;
        border: 1px solid #cbd5e1; background: #f1f5f9; color: #64748b;
        font-size: 18px; line-height: 1; font-weight: 500;
        display: flex; align-items: center; justify-content: center;
        transition: background 0.15s, border-color 0.15s, color 0.15s;
      }
      button.close-x:hover {
        background: rgba(244,63,94,0.12); border-color: rgba(244,63,94,0.35); color: #e11d48;
      }
      .card.dark button.close-x {
        background: rgba(255,255,255,0.06); border-color: rgba(255,255,255,0.1);
        color: rgba(148,163,184,0.85);
      }
      .card.dark button.close-x:hover {
        background: rgba(244,63,94,0.15); border-color: rgba(244,63,94,0.3); color: #f43f5e;
      }
      button:disabled { opacity: 0.5; cursor: default; }
      .feedback { display: none; gap: 8px; margin-top: 12px; flex-wrap: wrap; align-items: center; }
      .feedback.visible { display: flex; }
      .feedback-note { font-size: 12px; opacity: 0.7; display: none; }
      .feedback-note.visible { display: inline; }
    </style>
    <div class="backdrop">
      <div class="card ${document.documentElement.dataset.akaTheme==="dark"?"dark":""}">
        <div class="header">
          <h2>${j(t)}</h2>
          <button type="button" class="close-x" id="close" aria-label="Close" title="Close">&times;</button>
        </div>
        <div class="focus" id="focus">${j(o)}</div>
        <div class="meta" id="meta">Generating…</div>
        <div class="body" id="body"></div>
        <div class="feedback" id="feedback">
          <button class="like" id="like">👍 Like</button>
          <span class="feedback-note" id="feedback-note">Liked</span>
        </div>
        <div class="actions">
          <button class="save" id="save">Save</button>
          <button class="primary" id="copy">Copy</button>
        </div>
      </div>
    </div>
  `;const u=a.getElementById("body"),s=a.getElementById("meta"),d=a.getElementById("feedback"),m=a.getElementById("feedback-note"),g=a.getElementById("like"),h=a.getElementById("save");let y="",x=!1,p=!1;const v=()=>{const b=(y||u.textContent||"").trim(),S=(r||o||"").trim();return S&&b?`${S}

${b}`:b||S};(k=a.getElementById("close"))==null||k.addEventListener("click",G),(C=a.querySelector(".backdrop"))==null||C.addEventListener("click",b=>{b.target===b.currentTarget&&G()}),($=a.getElementById("copy"))==null||$.addEventListener("click",()=>{navigator.clipboard.writeText(v()),_("Copied")}),h.addEventListener("click",()=>{if(p)return;const b=v().trim();if(!b){_("Nothing to save yet");return}(async()=>{h.disabled=!0;try{await A({type:I.SAVE_HIGHLIGHT,text:b,url:location.href,title:document.title}),p=!0,h.textContent="Saved!",_("Highlight saved")}catch(S){h.disabled=!1,_(S instanceof Error?S.message:"Save failed")}})()});async function w(){if(x)return;const b=(y||u.textContent||"").slice(0,200);if(b.trim()){x=!0,g.disabled=!0;try{await A({type:I.PERSONALIZATION_FEEDBACK,accepted:!0,action:l,textPreview:b}),m.classList.add("visible"),_("Liked — preferences updated")}catch(S){x=!1,g.disabled=!1,_(S instanceof Error?S.message:"Feedback failed")}}}g.addEventListener("click",()=>void w());const P=b=>{if(b.requestId===i){if(b.type===I.AI_STREAM_CHUNK&&b.chunk){if(y.length||(s.textContent="Streaming…"),y+=b.chunk,M(y)&&y.length>120){y="Could not produce a clean summary for this selection. Try again.",u.innerHTML=`<p>${j(y)}</p>`,s.textContent="Filtered page chrome";return}try{u.innerHTML=we.parse(y,{async:!1})}catch{u.textContent=y}}b.type===I.AI_STREAM_DONE&&(b.error?s.textContent=b.error:b.envelope?(s.textContent=`${b.envelope.latencyMs??0}ms`,d.classList.add("visible")):(s.textContent="Done",d.classList.add("visible")),chrome.runtime.onMessage.removeListener(P))}};chrome.runtime.onMessage.addListener(P),A({type:I.AI_STREAM,requestId:i,action:l,text:n,selectedText:r,pageContext:c,pageTitle:document.title,url:location.href}).catch(b=>{s.textContent=b instanceof Error?b.message:"AI failed"})}function G(){L==null||L.remove(),L=null}function _(e){const t=document.createElement("div");t.textContent=e,Object.assign(t.style,{position:"fixed",bottom:"24px",right:"24px",zIndex:"2147483647",background:"#0f172a",color:"#fff",padding:"10px 14px",borderRadius:"10px",fontFamily:"Segoe UI, sans-serif",fontSize:"13px",boxShadow:"0 8px 24px rgba(0,0,0,0.25)"}),document.documentElement.appendChild(t),setTimeout(()=>t.remove(),2200)}function Ke(e){if(!Q())return;const t=e.composedPath();if(Fe(t)||t.some(r=>r===z||r===L))return;const o=window.getSelection(),n=(o==null?void 0:o.toString().trim())??"";if(!n||n.length<2){ie();return}qe(e.clientX+8,e.clientY+8,n)}function Ue(e){e.key==="Escape"&&(ie(),G(),Ne())}function je(){const e=(R==null?void 0:R.theme)??"light";let t=e;e==="system"&&(t=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"),document.documentElement.dataset.akaTheme=t}function ne(){je(),ye(ee())}async function We(){if(Q()){try{chrome.storage.local.remove(["hs_keyword_cache_v1","aka_keyword_cache_v1"],()=>{var e;try{(e=chrome.runtime)==null||e.lastError}catch{}})}catch{}try{await pe()}catch{R=null}ne(),document.addEventListener("mouseup",Ke),document.addEventListener("keydown",Ue);try{chrome.storage.onChanged.addListener((e,t)=>{try{if(t!=="local")return;(e.theme||e.hs_feature_prefs)&&pe().then(()=>ne())}catch{}})}catch{}}}We();let fe=location.href;setInterval(()=>{location.href!==fe&&(fe=location.href,Ae(),ye(ee()))},1500);
//# sourceMappingURL=index.ts-CNSCGphT.js.map
